/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package battleship;

/**
 *
 * @author 30698
 */
public abstract class Ship {
    
    int length;
    int points;
    char letter;
    String field;
    
    public Ship(int length, int points, char letter, String field){
        this.length = length;
        this.points = points;
        this.letter = letter;
        this.field = field;         
    }
    
    public int hit(int lenght){
        return --length;
    }
    
    public String getHitMessage(){
        return "You Hit A Ship";
    }
    
    public String getSinkMessage(){
        return "Ship sank!" + "/n" +"Nice Work Commander";
    }
    
    abstract boolean  isHit(int length);
    
    abstract void threaten();
    
    abstract boolean isSinking(int length);
}