/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package battleship;

/**
 *
 * @author 30698
 */
public class Submarine extends Ship {

    public Submarine(int length, int points, char letter, String field) {
        super(length, points, letter, field);
    }

    boolean isHit(int length) {
        return length < 1;
    }

 
    void threaten() {
        
    }
    
    boolean isSinking(int length){
        return length == 0;
    }
}
