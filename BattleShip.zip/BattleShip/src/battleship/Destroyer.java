/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package battleship;

/**
 *
 * @author 30698
 */
public class Destroyer extends Ship {

    public Destroyer(int length, int points, char letter, String field) {
        super(length, points, letter, field);
    }

    boolean isHit(int length) {
           return length <3;
    }


    void threaten() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    boolean isSinking(int length){
        return length == 0;
    }
}
